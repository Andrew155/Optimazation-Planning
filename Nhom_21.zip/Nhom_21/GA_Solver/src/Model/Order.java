package Model;

public class Order {
    public int cost;
    public int profit;
    public Order(int cost, int profit){
        this.cost = cost;
        this.profit = profit;
    }
}

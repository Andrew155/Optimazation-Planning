import Model.Vehicle;

public class Main {
    public static void main(String[] args) {
        GA g = new GA();
        g.run();
    }
}